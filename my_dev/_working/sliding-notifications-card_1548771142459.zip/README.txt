A Pen created at CodePen.io. You can find this one at https://codepen.io/Artemis1/pen/GPwyro.

 100dayscss - 007
#Sliding notifications card
Simple ui design, feed animation, hidden navigation, sliding card to show menu.
Burger icon micro-interaction + hover effect on nav items from @IanLunn 's amazing hover.css library
Just a touch of jquery to fire event on click