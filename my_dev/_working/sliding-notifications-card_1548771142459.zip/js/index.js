// jQuery v3.3.1 is supported
$('.menu-icon').click( function() {
    $('.panel').toggleClass('show-menu');
    $('.menu').toggleClass('active');
	$('.circle-1').toggleClass('slide');
	$('.dash-top').toggleClass('slide-top');
});