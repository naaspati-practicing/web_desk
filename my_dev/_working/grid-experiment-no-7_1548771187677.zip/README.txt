A Pen created at CodePen.io. You can find this one at https://codepen.io/julesforrest/pen/VqXvgQ.

 A creation of NYC's Russ & Daughters cafe menu.