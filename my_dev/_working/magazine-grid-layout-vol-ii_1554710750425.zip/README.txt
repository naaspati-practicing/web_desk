A Pen created at CodePen.io. You can find this one at https://codepen.io/ilithya/pen/GebVqo.

 Responsive grid layout for #CodePenChallenge Stellar Scientists—a tribute to Albertus Seba.

Experimenting with responsive CSS Grid + CSS Columns properties.