/* 
 * PURE CSS MAGAZINE GRID LAYOUT VOL. II
 * Responsive grid layout for #CodePenChallenge Stellar Scientists. 
 * A tribute to Albertus Seba.
 * CSS Grid + CSS Columns.
 *
 * Designed fully inspired by a real magazine.
 * By ilithya | 2019
 */