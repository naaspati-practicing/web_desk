A Pen created at CodePen.io. You can find this one at https://codepen.io/akshaycodes/pen/wRQvow.

 This Pen is a versatile solution for making your header, sidebar, hamburger menu or footer, blend in seamlessly like a chameleon... Posiblity are endless just add a #chameleon id to a class you want to sample a color from and add  a  #target id to a class you want  sample color to... That's it  
