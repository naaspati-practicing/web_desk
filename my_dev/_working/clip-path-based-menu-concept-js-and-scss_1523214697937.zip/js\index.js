$(document).ready(()=> {
	const $CANVES = $('#canves'),
				$MENU = $CANVES.find('.menu');
	
	$MENU.find('i').on('click', function(e) {
		e.preventPropagation;
		let $this = $(this);
		$CANVES.toggleClass('open-menu');
		$this.css('pointer-events', 'none');
		if($this.parent().hasClass('active')) { 
			$MENU.find('ul').hide();
			setTimeout(()=> {
				$this.parent().toggleClass('active');	
			}, 50);
		} else {
			$this.parent().addClass('active');	
			setTimeout(()=> {
				$MENU.find('ul').fadeToggle();
			}, 200);					
		}
		setTimeout(()=> {
			$this.css('pointer-events', 'all');
		}, 500)
	})
	
	$MENU.find('[data-view]:not(.active)').on('click', function() {
		var $this = $(this);
		$MENU.find('.active').removeClass('active');
		$this.addClass('active');
		$MENU.find('ul').hide();
		$MENU.removeClass('active');
		$CANVES.removeClass('open-menu');
		setTimeout(()=> {
			$CANVES.attr('data-view', $this.data('view'));
		}, 250);		
	})
	
})