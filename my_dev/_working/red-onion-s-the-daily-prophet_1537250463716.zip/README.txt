A Pen created at CodePen.io. You can find this one at https://codepen.io/analizapandac/pen/NLMemQ.

 I created a copy of the Red Onion's Daily Prophet (http://redonion.se/cssgrid/) using flexbox.  All rights reserved to Red Onion (http://redonion.se/en/home/).